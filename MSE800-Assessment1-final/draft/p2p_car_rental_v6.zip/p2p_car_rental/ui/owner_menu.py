"""
Owner Menu
==========
Handles owner-specific operations.
"""

from services.car_service import CarService
from services.booking_service import BookingService
from services.review_service import ReviewService
from utils.helpers import (
    clear_screen, print_header, print_section, print_success, print_error,
    print_info, print_table, print_dict_as_table, prompt, prompt_int,
    prompt_float, format_currency, pause,
)


def show_owner_menu(user):
    """Display the owner menu and handle choices."""
    car_svc = CarService()
    booking_svc = BookingService()
    review_svc = ReviewService()

    while True:
        clear_screen()
        print(user.view_dashboard())

        # Show average rating
        avg = review_svc.get_user_avg_rating(user.id)
        if avg > 0:
            print_info(f"Average rating: {avg}/5")

        print()
        print("  1. View my cars")
        print("  2. Add new car listing")
        print("  3. Remove car listing")
        print("  4. View pending bookings")
        print("  5. Approve / Reject booking")
        print("  6. View earnings")
        print("  7. View profile")
        print("  8. Logout")
        print()

        choice = prompt("Select option")

        if choice == '1':
            _view_my_cars(user, car_svc)
        elif choice == '2':
            _add_car(user, car_svc)
        elif choice == '3':
            _remove_car(user, car_svc)
        elif choice == '4':
            _view_pending_bookings(user, booking_svc)
        elif choice == '5':
            _approve_reject_booking(user, booking_svc)
        elif choice == '6':
            _view_earnings(user, booking_svc)
        elif choice == '7':
            print_dict_as_table(user.view_profile(), "MY PROFILE")
            pause()
        elif choice == '8':
            break
        else:
            print_error("Invalid choice")
            pause()


def _view_my_cars(user, car_svc):
    """Show the owner's car listings."""
    clear_screen()
    print_header("MY CARS")

    cars = car_svc.get_owner_cars(user.id)
    if len(cars) == 0:
        print_info("You don't have any cars listed yet.")
    else:
        rows = []
        for car in cars:
            if car.is_approved:
                status = "Approved"
            else:
                status = "Pending"
            rows.append([
                car.id, f"{car.year} {car.make} {car.model}",
                car.location, format_currency(car.daily_rate), status,
            ])
        print_table(rows, ['ID', 'Vehicle', 'Location', 'Rate/day', 'Status'])
    pause()


def _add_car(user, car_svc):
    """Add a new car listing."""
    clear_screen()
    print_header("ADD NEW CAR")

    make = prompt("Make (e.g. Toyota)")
    model = prompt("Model (e.g. Camry)")
    year = prompt_int("Year", min_value=1980, max_value=2030)
    mileage = prompt_int("Mileage (km)", min_value=0)
    location = prompt("Location (city)")
    daily_rate = prompt_float("Daily rate ($)", min_value=1)
    min_period = prompt_int("Min rental period (days)", min_value=1)
    max_period = prompt_int("Max rental period (days)", min_value=min_period)

    ok, msg, _ = car_svc.add_car(user.id, make, model, year, mileage,
                                  location, daily_rate, min_period, max_period)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()


def _remove_car(user, car_svc):
    """Remove a car listing."""
    clear_screen()
    print_header("REMOVE CAR")

    cars = car_svc.get_owner_cars(user.id)
    if len(cars) == 0:
        print_info("You don't have any cars to remove.")
        pause()
        return

    rows = []
    for car in cars:
        rows.append([car.id, f"{car.year} {car.make} {car.model}"])
    print_table(rows, ['ID', 'Vehicle'])

    car_id = prompt_int("Enter car ID to remove")
    ok, msg = car_svc.remove_car(user.id, car_id)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()


def _view_pending_bookings(user, booking_svc):
    """Show pending bookings for the owner."""
    clear_screen()
    print_header("PENDING BOOKINGS")

    bookings = booking_svc.get_owner_bookings(user.id, status='pending')
    if len(bookings) == 0:
        print_info("No pending bookings.")
    else:
        rows = []
        for b in bookings:
            rows.append([
                b['id'], b['renter_name'],
                f"{b['year']} {b['make']} {b['model']}",
                f"{b['start_date']} to {b['end_date']}",
                format_currency(b['total_amount']),
            ])
        print_table(rows, ['ID', 'Renter', 'Car', 'Period', 'Total'])
    pause()


def _approve_reject_booking(user, booking_svc):
    """Approve or reject a pending booking."""
    clear_screen()
    print_header("APPROVE / REJECT BOOKING")

    bookings = booking_svc.get_owner_bookings(user.id, status='pending')
    if len(bookings) == 0:
        print_info("No pending bookings.")
        pause()
        return

    rows = []
    for b in bookings:
        rows.append([
            b['id'], b['renter_name'],
            f"{b['start_date']} to {b['end_date']}",
            format_currency(b['total_amount']),
        ])
    print_table(rows, ['ID', 'Renter', 'Period', 'Total'])

    booking_id = prompt_int("Enter booking ID")
    print("\n  1. Approve")
    print("  2. Reject")
    action = prompt("Choose action")

    if action == '1':
        ok, msg = booking_svc.approve_booking(booking_id, user.id)
    elif action == '2':
        ok, msg = booking_svc.reject_booking(booking_id, user.id)
    else:
        print_error("Invalid action")
        pause()
        return

    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()


def _view_earnings(user, booking_svc):
    """Show the owner's total earnings."""
    clear_screen()
    print_header("MY EARNINGS")

    earnings = booking_svc.get_owner_earnings(user.id)
    print()
    print_info(f"Total earnings: {format_currency(earnings)}")
    pause()
