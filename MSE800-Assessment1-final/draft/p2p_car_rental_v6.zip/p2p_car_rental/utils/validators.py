"""
Input validators
================
Functions to validate user input.
"""

import re
from datetime import datetime


def is_valid_email(email):
    """Check if the email format is valid."""
    if not isinstance(email, str):
        return False
    # Simple email pattern: text@text.text
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None


def is_valid_password(password):
    """Check if the password is strong enough.

    Returns a tuple: (is_valid, error_message)
    """
    if not isinstance(password, str):
        return False, "Password must be text"
    if len(password) < 6:
        return False, "Password must be at least 6 characters"
    return True, "OK"


def is_valid_date(date_string):
    """Check if the date string is in YYYY-MM-DD format."""
    try:
        datetime.strptime(date_string, "%Y-%m-%d")
        return True
    except (ValueError, TypeError):
        return False


def is_valid_phone(phone):
    """Check if the phone number is valid (simple check)."""
    if not isinstance(phone, str):
        return False
    # Remove spaces and dashes
    cleaned = phone.replace(' ', '').replace('-', '').replace('+', '')
    # Must be all digits and 7-15 chars long
    return cleaned.isdigit() and 7 <= len(cleaned) <= 15
