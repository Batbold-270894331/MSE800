"""
Security utilities
==================
Password hashing using SHA-256 with salt.

Why hash passwords?
    Storing raw passwords is a critical security vulnerability.
    If the database is leaked, attackers see every password directly.
    Hashing makes the stored value useless even if leaked.

Why use salt?
    Without salt, two users with password "abc123" produce identical
    hashes. With salt, every hash is unique. Salt also defeats
    rainbow-table attacks.
"""

import hashlib
from config import PASSWORD_SALT


def hash_password(password):
    """Hash a password using SHA-256 with the configured salt.

    Returns a hex string (64 characters long).
    """
    # Concatenate password and salt before hashing
    salted = password + PASSWORD_SALT
    # hashlib requires bytes, not a string
    salted_bytes = salted.encode('utf-8')
    # hexdigest() returns a readable hex string
    return hashlib.sha256(salted_bytes).hexdigest()


def verify_password(password, hashed):
    """Verify a plain-text password against a stored hash.

    We hash the input and compare to the stored hash.
    We never decrypt - you can't un-hash a password (that's the point).
    """
    return hash_password(password) == hashed
