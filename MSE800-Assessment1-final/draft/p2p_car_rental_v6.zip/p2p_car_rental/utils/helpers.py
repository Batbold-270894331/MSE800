"""
Helper utilities
================
CLI display helpers and date utilities.
"""

import os
from datetime import datetime
from tabulate import tabulate
from colorama import init, Fore, Style

# Initialize colorama (needed for Windows)
init(autoreset=True)


def clear_screen():
    """Clear the terminal screen (cross-platform)."""
    # Windows uses 'cls', Linux/macOS use 'clear'
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')


def print_header(title):
    """Print a styled section header."""
    print(Fore.CYAN + "\n" + "=" * 60)
    print(Fore.CYAN + Style.BRIGHT + title.center(60))
    print(Fore.CYAN + "=" * 60 + Style.RESET_ALL)


def print_section(title):
    """Print a smaller section divider."""
    print(Fore.YELLOW + "\n" + "-" * 60)
    print(Fore.YELLOW + " " + title)
    print(Fore.YELLOW + "-" * 60 + Style.RESET_ALL)


def print_success(message):
    """Print a success message in green."""
    print(Fore.GREEN + f"[OK] {message}" + Style.RESET_ALL)


def print_error(message):
    """Print an error message in red."""
    print(Fore.RED + f"[ERROR] {message}" + Style.RESET_ALL)


def print_info(message):
    """Print an info message in blue."""
    print(Fore.BLUE + f"[INFO] {message}" + Style.RESET_ALL)


def print_table(rows, headers):
    """Print a pretty table using tabulate."""
    if len(rows) == 0:
        print(Fore.YELLOW + "  (no data to display)" + Style.RESET_ALL)
        return
    print(tabulate(rows, headers=headers, tablefmt='grid'))


def print_dict_as_table(d, title=None):
    """Print a dictionary as a 2-column table."""
    if title:
        print_section(title)
    rows = [[k, v] for k, v in d.items()]
    print(tabulate(rows, headers=['Field', 'Value'], tablefmt='grid'))


def prompt(message, allow_empty=False):
    """Prompt the user for input."""
    while True:
        value = input(Fore.YELLOW + f"{message}: " + Style.RESET_ALL).strip()
        if value or allow_empty:
            return value
        print_error("This field cannot be empty.")


def prompt_int(message, min_value=None, max_value=None):
    """Prompt the user for an integer."""
    while True:
        text = prompt(message)
        try:
            value = int(text)
            if min_value is not None and value < min_value:
                print_error(f"Value must be at least {min_value}")
                continue
            if max_value is not None and value > max_value:
                print_error(f"Value must be at most {max_value}")
                continue
            return value
        except ValueError:
            print_error("Please enter a valid integer.")


def prompt_float(message, min_value=None):
    """Prompt the user for a float."""
    while True:
        text = prompt(message)
        try:
            value = float(text)
            if min_value is not None and value < min_value:
                print_error(f"Value must be at least {min_value}")
                continue
            return value
        except ValueError:
            print_error("Please enter a valid number.")


def prompt_date(message):
    """Prompt the user for a date in YYYY-MM-DD format."""
    while True:
        text = prompt(message + " (YYYY-MM-DD)")
        try:
            datetime.strptime(text, "%Y-%m-%d")
            return text
        except ValueError:
            print_error("Please enter a valid date (YYYY-MM-DD).")


def prompt_yes_no(message):
    """Prompt the user for yes/no (returns True/False)."""
    while True:
        text = prompt(message + " (y/n)").lower()
        if text in ('y', 'yes'):
            return True
        if text in ('n', 'no'):
            return False
        print_error("Please answer y or n.")


def days_between(start_date, end_date):
    """Calculate the number of days between two date strings (YYYY-MM-DD)."""
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    delta = end - start
    return delta.days


def format_currency(amount):
    """Format a number as currency."""
    return f"${amount:,.2f}"


def pause():
    """Wait for the user to press Enter."""
    input(Fore.YELLOW + "\nPress Enter to continue..." + Style.RESET_ALL)
