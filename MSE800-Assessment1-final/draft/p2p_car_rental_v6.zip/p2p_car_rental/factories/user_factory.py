"""
User Factory - Factory Method Pattern
======================================
Creates the appropriate User subclass based on role.

This centralizes user creation - if we need to add a new role
(like 'fleet_manager'), we change only this file.
"""

from models.owner import Owner
from models.renter import Renter
from models.admin import Admin


class UserFactory:
    """Factory class to create User instances based on role."""

    @staticmethod
    def create(role, user_id, name, email, password_hash, phone,
               license_number=None, is_verified=False):
        """Create a User instance (Owner, Renter, or Admin) based on role.

        Args:
            role: 'owner', 'renter', or 'admin'
            user_id, name, email, etc.: user attributes

        Returns:
            Owner, Renter, or Admin instance

        Raises:
            ValueError if role is unknown
        """
        role = role.lower()

        if role == 'owner':
            return Owner(user_id, name, email, password_hash, phone,
                         license_number, is_verified)
        elif role == 'renter':
            return Renter(user_id, name, email, password_hash, phone,
                          license_number, is_verified)
        elif role == 'admin':
            return Admin(user_id, name, email, password_hash, phone,
                         license_number, is_verified)
        else:
            raise ValueError(f"Unknown role: {role}")

    @staticmethod
    def from_db_row(row):
        """Create a User instance from a database row.
        The row is a sqlite3.Row that behaves like a dictionary."""
        # Get license_number safely (may not be in all queries)
        license_number = None
        if 'license_number' in row.keys():
            license_number = row['license_number']

        return UserFactory.create(
            role=row['role'],
            user_id=row['id'],
            name=row['name'],
            email=row['email'],
            password_hash=row['password_hash'],
            phone=row['phone'],
            license_number=license_number,
            is_verified=row['is_verified'],
        )
