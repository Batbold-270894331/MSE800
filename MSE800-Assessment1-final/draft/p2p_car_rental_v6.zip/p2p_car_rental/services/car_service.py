"""
Car Service
===========
Handles car-related business logic:
  - Add and remove car listings
  - Search and filter cars
  - Admin approval of car listings
"""

from database.db_manager import DatabaseManager
from models.car import Car


class CarService:
    """Service for managing cars on the platform."""

    def __init__(self):
        self.db = DatabaseManager()

    def add_car(self, owner_id, make, model, year, mileage, location,
                daily_rate, min_rent_period=1, max_rent_period=30):
        """Add a new car listing. Status starts as pending approval.

        Returns a tuple: (success, message, car_id_or_None)
        """
        try:
            cursor = self.db.execute("""
                INSERT INTO cars (owner_id, make, model, year, mileage,
                                  location, daily_rate, min_rent_period,
                                  max_rent_period, is_approved, is_available)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 1)
            """, (owner_id, make, model, year, mileage, location,
                  daily_rate, min_rent_period, max_rent_period))

            car_id = cursor.lastrowid
            return True, f"Car added (ID: {car_id}). Awaiting admin approval.", car_id
        except Exception as e:
            return False, f"Failed to add car: {e}", None

    def remove_car(self, owner_id, car_id):
        """Remove a car listing (only if owned by this owner).

        Returns a tuple: (success, message)
        """
        # Check that the car exists and belongs to this owner
        car = self.db.fetch_one(
            "SELECT * FROM cars WHERE id = ? AND owner_id = ?",
            (car_id, owner_id)
        )
        if car is None:
            return False, "Car not found or you don't own it"

        # Don't allow removing cars with active bookings
        active = self.db.fetch_one("""
            SELECT id FROM bookings
            WHERE car_id = ? AND status IN ('pending', 'approved')
        """, (car_id,))
        if active is not None:
            return False, "Cannot remove car with active bookings"

        self.db.execute("DELETE FROM cars WHERE id = ?", (car_id,))
        return True, "Car removed successfully"

    def get_owner_cars(self, owner_id):
        """Get all cars owned by a specific owner."""
        rows = self.db.fetch_all(
            "SELECT * FROM cars WHERE owner_id = ? ORDER BY id DESC",
            (owner_id,)
        )
        # Convert each database row into a Car object
        cars = []
        for row in rows:
            cars.append(self._row_to_car(row))
        return cars

    def search_cars(self, location=None, max_price=None):
        """Search for available, approved cars.
        Optional filters: location, max_price.
        """
        # Build the query step by step
        query = """
            SELECT c.* FROM cars c
            JOIN users u ON c.owner_id = u.id
            WHERE c.is_approved = 1
              AND c.is_available = 1
              AND u.is_verified = 1
        """
        params = []

        # Add location filter if given
        if location is not None and location != '':
            query = query + " AND LOWER(c.location) LIKE LOWER(?)"
            params.append(f"%{location}%")

        # Add max price filter if given
        if max_price is not None:
            query = query + " AND c.daily_rate <= ?"
            params.append(max_price)

        # Sort by price (cheapest first)
        query = query + " ORDER BY c.daily_rate ASC"

        rows = self.db.fetch_all(query, params)
        cars = []
        for row in rows:
            cars.append(self._row_to_car(row))
        return cars

    def get_car_by_id(self, car_id):
        """Get a single car by ID. Returns None if not found."""
        row = self.db.fetch_one("SELECT * FROM cars WHERE id = ?", (car_id,))
        if row is None:
            return None
        return self._row_to_car(row)

    def get_pending_cars(self):
        """Admin: get all cars waiting for approval."""
        rows = self.db.fetch_all(
            "SELECT * FROM cars WHERE is_approved = 0 ORDER BY id"
        )
        cars = []
        for row in rows:
            cars.append(self._row_to_car(row))
        return cars

    def approve_car(self, car_id):
        """Admin: approve a car listing."""
        self.db.execute(
            "UPDATE cars SET is_approved = 1 WHERE id = ?", (car_id,)
        )
        return True, f"Car #{car_id} approved"

    def reject_car(self, car_id):
        """Admin: reject (delete) a car listing."""
        self.db.execute("DELETE FROM cars WHERE id = ?", (car_id,))
        return True, f"Car #{car_id} rejected and removed"

    def _row_to_car(self, row):
        """Helper method: convert a database row into a Car object."""
        if row is None:
            return None
        return Car(
            car_id=row['id'],
            owner_id=row['owner_id'],
            make=row['make'],
            model=row['model'],
            year=row['year'],
            mileage=row['mileage'],
            location=row['location'],
            daily_rate=row['daily_rate'],
            min_rent_period=row['min_rent_period'],
            max_rent_period=row['max_rent_period'],
            is_approved=row['is_approved'],
            is_available=row['is_available'],
        )
