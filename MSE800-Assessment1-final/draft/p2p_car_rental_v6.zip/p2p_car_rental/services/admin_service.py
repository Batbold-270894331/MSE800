"""
Admin Service
=============
Admin operations:
  - Verify users (KYC)
  - Handle insurance claims
  - View platform statistics
  - Suspend users
"""

from database.db_manager import DatabaseManager


class AdminService:
    """Service for admin operations."""

    def __init__(self):
        self.db = DatabaseManager()

    def get_pending_users(self):
        """Get all users waiting for verification."""
        return self.db.fetch_all("""
            SELECT * FROM users
            WHERE is_verified = 0 AND role != 'admin'
            ORDER BY id
        """)

    def verify_user(self, user_id):
        """Mark a user as verified (KYC passed).

        Returns a tuple: (success, message)
        """
        user = self.db.fetch_one("SELECT * FROM users WHERE id = ?", (user_id,))
        if user is None:
            return False, "User not found"

        self.db.execute(
            "UPDATE users SET is_verified = 1 WHERE id = ?", (user_id,)
        )
        return True, f"User #{user_id} ({user['name']}) verified"

    def suspend_user(self, user_id):
        """Suspend a user (un-verify them).
        We don't delete because we need their booking history.

        Returns a tuple: (success, message)
        """
        user = self.db.fetch_one("SELECT * FROM users WHERE id = ?", (user_id,))
        if user is None:
            return False, "User not found"

        # Safety check: never suspend an admin
        if user['role'] == 'admin':
            return False, "Cannot suspend admin"

        self.db.execute(
            "UPDATE users SET is_verified = 0 WHERE id = ?", (user_id,)
        )
        return True, f"User #{user_id} suspended"

    def get_pending_claims(self):
        """Get all pending insurance claims with car info."""
        return self.db.fetch_all("""
            SELECT ic.*, b.car_id, c.make, c.model
            FROM insurance_claims ic
            JOIN bookings b ON ic.booking_id = b.id
            JOIN cars c ON b.car_id = c.id
            WHERE ic.status = 'pending'
            ORDER BY ic.id
        """)

    def file_claim(self, booking_id, description, claim_amount):
        """File a new insurance claim (usually by owner after rental).

        Returns a tuple: (success, message, claim_id_or_None)
        """
        try:
            cursor = self.db.execute("""
                INSERT INTO insurance_claims (booking_id, description, claim_amount)
                VALUES (?, ?, ?)
            """, (booking_id, description, claim_amount))

            claim_id = cursor.lastrowid
            return True, f"Claim #{claim_id} filed", claim_id
        except Exception as e:
            return False, f"Failed: {e}", None

    def approve_claim(self, claim_id):
        """Approve an insurance claim (insurance pays out)."""
        self.db.execute(
            "UPDATE insurance_claims SET status='approved' WHERE id = ?",
            (claim_id,)
        )
        return True, f"Claim #{claim_id} approved"

    def reject_claim(self, claim_id):
        """Reject an insurance claim (no payout)."""
        self.db.execute(
            "UPDATE insurance_claims SET status='rejected' WHERE id = ?",
            (claim_id,)
        )
        return True, f"Claim #{claim_id} rejected"

    def get_platform_stats(self):
        """Get platform-wide statistics as a dictionary."""
        # Count users by role
        total_users = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM users"
        )['c']
        total_owners = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM users WHERE role = 'owner'"
        )['c']
        total_renters = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM users WHERE role = 'renter'"
        )['c']

        # Count cars
        total_cars = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM cars"
        )['c']
        approved_cars = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM cars WHERE is_approved = 1"
        )['c']

        # Count bookings
        total_bookings = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM bookings"
        )['c']
        approved_bookings = self.db.fetch_one(
            "SELECT COUNT(*) AS c FROM bookings WHERE status = 'approved'"
        )['c']

        # Total platform revenue (sum of platform fees)
        revenue_row = self.db.fetch_one("""
            SELECT COALESCE(SUM(platform_fee), 0) AS revenue
            FROM bookings
            WHERE status IN ('approved', 'completed')
        """)
        revenue = revenue_row['revenue']

        # Build the result dictionary for display
        return {
            'Total Users':       total_users,
            'Owners':            total_owners,
            'Renters':           total_renters,
            'Total Cars':        total_cars,
            'Approved Cars':     approved_cars,
            'Total Bookings':    total_bookings,
            'Approved Bookings': approved_bookings,
            'Platform Revenue':  f"${revenue:,.2f}",
        }
