"""
P2P Car Rental System - Main Entry Point
=========================================
A peer-to-peer car rental platform connecting car owners with renters.

USAGE
-----
    # Default (development environment):
    python main.py

    # Test environment (in-memory DB):
    APP_ENV=test python main.py        # Linux/macOS
    set APP_ENV=test && python main.py # Windows

    # Production environment:
    APP_ENV=prod python main.py

ARCHITECTURE
------------
The system has 4 layers:
    1. Presentation (ui/)      - CLI menus
    2. Service     (services/) - Business logic
    3. Model       (models/)   - OOP entities
    4. Data Access (database/) - SQLite database

DESIGN PATTERNS
---------------
    - Singleton  (DatabaseManager)
    - Factory    (UserFactory)
    - Strategy   (InsuranceStrategy)

OOP PRINCIPLES
--------------
    - Encapsulation:  Protected attributes with @property decorator
    - Inheritance:    Owner, Renter, Admin extend User
    - Abstraction:    User is abstract (abc.ABC with @abstractmethod)
    - Polymorphism:   view_dashboard() differs per role
"""

import sys

# Import config first so all downstream modules see consistent settings
from config import DEBUG, print_active_config
from database.db_manager import DatabaseManager
from ui.main_menu import show_main_menu


def main():
    """Application entry point.

    Returns:
        Exit code: 0 on success, 1 on error.
    """
    try:
        # Step 1: Show which environment we're running (helpful for debugging)
        if DEBUG:
            print_active_config()

        # Step 2: Initialize the Singleton database manager
        # This call:
        #   - Opens the SQLite connection
        #   - Creates all tables (if not exist)
        #   - Seeds the default admin account
        # All future DatabaseManager() calls return this SAME instance.
        DatabaseManager()

        # Step 3: Show the main menu (runs until user picks Exit)
        show_main_menu()

        return 0  # exited normally

    except KeyboardInterrupt:
        # User hit Ctrl+C - this is normal, not an error
        print("\n\n[INFO] Program interrupted by user. Goodbye!")
        return 0

    except Exception as e:
        # Catch any uncaught exception
        print(f"\n[FATAL ERROR] {e}")
        # Show full traceback in debug mode
        if DEBUG:
            import traceback
            traceback.print_exc()
        return 1

    finally:
        # Step 4: Always close the database connection cleanly
        # finally runs even after exceptions or Ctrl+C
        try:
            DatabaseManager().close()
        except Exception:
            # Don't crash on cleanup errors
            pass


# Standard Python pattern: only run main() when this file is executed directly
# (not when imported as a module)
if __name__ == '__main__':
    sys.exit(main())
