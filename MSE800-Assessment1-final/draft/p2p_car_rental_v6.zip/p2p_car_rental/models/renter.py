"""
Renter model
============
A user who rents cars from owners.
Inherits from User.
"""

from models.user import User


class Renter(User):
    """Renter - searches for and books cars."""

    def __init__(self, user_id, name, email, password_hash, phone,
                 license_number=None, is_verified=False):
        super().__init__(user_id, name, email, password_hash, phone,
                         'renter', license_number, is_verified)

    def view_dashboard(self):
        """Renter-specific dashboard (Polymorphism)."""
        return f"""
        ╔══════════════════════════════════════════╗
        ║   RENTER DASHBOARD - {self._name:<21} ║
        ╚══════════════════════════════════════════╝
        """
