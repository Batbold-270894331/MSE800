"""
Admin model
===========
Platform administrator who verifies users and approves listings.
Inherits from User.
"""

from models.user import User


class Admin(User):
    """Admin - moderates the platform."""

    def __init__(self, user_id, name, email, password_hash, phone,
                 license_number=None, is_verified=True):
        # Admins are auto-verified (is_verified defaults to True)
        super().__init__(user_id, name, email, password_hash, phone,
                         'admin', license_number, is_verified)

    def view_dashboard(self):
        """Admin-specific dashboard (Polymorphism)."""
        return f"""
        ╔══════════════════════════════════════════╗
        ║   ADMIN DASHBOARD - {self._name:<22} ║
        ╚══════════════════════════════════════════╝
        """
