"""
User model - Abstract base class
=================================
Demonstrates all four OOP principles (taught in Week 4b):
  - Abstraction: Uses abc.ABC and @abstractmethod
  - Encapsulation: Protected attributes (_prefix) with @property
  - Inheritance: Owner, Renter, Admin extend User
  - Polymorphism: view_dashboard() differs per role
"""

from abc import ABC, abstractmethod


class User(ABC):
    """Abstract base class for all users (Owner, Renter, Admin)."""

    def __init__(self, user_id, name, email, password_hash, phone,
                 role, license_number=None, is_verified=False):
        # Encapsulation: protected attributes (single underscore prefix)
        # These are accessed through @property methods below
        self._id = user_id
        self._name = name
        self._email = email
        self._password_hash = password_hash
        self._phone = phone
        self._role = role
        self._license_number = license_number
        self._is_verified = bool(is_verified)

    # @property decorators provide controlled access to protected attributes
    # This is Python's way of doing encapsulation (taught in Week 4b)

    @property
    def id(self):
        return self._id

    @property
    def name(self):
        return self._name

    @property
    def email(self):
        return self._email

    @property
    def phone(self):
        return self._phone

    @property
    def role(self):
        return self._role

    @property
    def license_number(self):
        return self._license_number

    @property
    def is_verified(self):
        return self._is_verified

    @property
    def password_hash(self):
        """Read-only access to password hash (used for authentication)."""
        return self._password_hash

    @abstractmethod
    def view_dashboard(self):
        """Abstract method: each subclass must implement its own dashboard.
        This is what makes User an abstract class (cannot be instantiated)."""
        pass

    def view_profile(self):
        """Return user profile information as a dictionary."""
        if self._is_verified:
            verified = "Yes"
        else:
            verified = "No (pending admin verification)"

        return {
            'ID': self._id,
            'Name': self._name,
            'Email': self._email,
            'Phone': self._phone,
            'Role': self._role.capitalize(),
            'Verified': verified,
        }

    def __str__(self):
        return f"{self._role.capitalize()}({self._name}, {self._email})"
