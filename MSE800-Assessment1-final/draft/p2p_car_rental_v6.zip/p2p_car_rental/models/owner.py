"""
Owner model
===========
A car owner who can list cars and approve bookings.
Inherits from User (demonstrates inheritance with super()).
"""

from models.user import User


class Owner(User):
    """Car owner - lists cars on the platform and earns rental income."""

    def __init__(self, user_id, name, email, password_hash, phone,
                 license_number=None, is_verified=False):
        # Call the parent constructor using super()
        # Pass role='owner' so the parent knows what type of user this is
        super().__init__(user_id, name, email, password_hash, phone,
                         'owner', license_number, is_verified)

    def view_dashboard(self):
        """Owner-specific dashboard (overrides abstract method - Polymorphism)."""
        return f"""
        ╔══════════════════════════════════════════╗
        ║   OWNER DASHBOARD - {self._name:<22} ║
        ╚══════════════════════════════════════════╝
        """
