"""
Database Manager - Singleton Pattern
=====================================
Manages the SQLite database connection.

Singleton pattern ensures only ONE database connection exists
across the whole application.
"""

import sqlite3
import os
from config import DB_FILE, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD


class DatabaseManager:
    """Singleton class for managing the SQLite database connection."""

    # Class-level variable shared across all instances
    # This is what makes it a Singleton
    _instance = None

    def __new__(cls):
        """Override __new__ to enforce the Singleton pattern.
        First call creates the instance; all later calls return the same one."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        """Setup the database connection, create tables, and seed data."""
        # Make sure the database folder exists (skip for in-memory DB)
        if DB_FILE != ':memory:':
            db_folder = os.path.dirname(DB_FILE)
            if db_folder and not os.path.exists(db_folder):
                os.makedirs(db_folder)

        # Connect to SQLite
        # check_same_thread=False allows access from any thread
        self._connection = sqlite3.connect(DB_FILE, check_same_thread=False)

        # Make rows accessible like dictionaries: row['email']
        # This is more readable than row[2]
        self._connection.row_factory = sqlite3.Row

        # Enable foreign keys (off by default in SQLite!)
        self._connection.execute("PRAGMA foreign_keys = ON")

        # Create tables and seed default admin
        self._create_tables()
        self._seed_default_admin()

    def execute(self, query, params=None):
        """Execute a parameterized SQL query.

        ALWAYS use parameterized queries (with ?) to prevent SQL injection.
        Never use f-strings or % to insert values into SQL!
        """
        cursor = self._connection.cursor()
        if params is None:
            cursor.execute(query)
        else:
            cursor.execute(query, params)
        # commit() saves changes (required for INSERT/UPDATE/DELETE)
        self._connection.commit()
        return cursor

    def fetch_one(self, query, params=None):
        """Execute a query and return ONE row (or None if no match)."""
        cursor = self.execute(query, params)
        return cursor.fetchone()

    def fetch_all(self, query, params=None):
        """Execute a query and return ALL matching rows."""
        cursor = self.execute(query, params)
        return cursor.fetchall()

    def close(self):
        """Close the database connection."""
        if self._connection is not None:
            self._connection.close()
            self._connection = None
            # Reset so a new instance can be created later
            DatabaseManager._instance = None

    def _create_tables(self):
        """Create all tables if they don't exist."""

        # USERS table - stores Owner, Renter, and Admin
        # The 'role' column tells us which type
        self.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                name            TEXT NOT NULL,
                email           TEXT UNIQUE NOT NULL,
                password_hash   TEXT NOT NULL,
                phone           TEXT,
                role            TEXT NOT NULL
                                CHECK(role IN ('owner','renter','admin')),
                license_number  TEXT,
                is_verified     INTEGER DEFAULT 0,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # CARS table - each car has one owner
        self.execute("""
            CREATE TABLE IF NOT EXISTS cars (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id        INTEGER NOT NULL,
                make            TEXT NOT NULL,
                model           TEXT NOT NULL,
                year            INTEGER NOT NULL,
                mileage         INTEGER DEFAULT 0,
                location        TEXT NOT NULL,
                daily_rate      REAL NOT NULL,
                min_rent_period INTEGER DEFAULT 1,
                max_rent_period INTEGER DEFAULT 30,
                is_approved     INTEGER DEFAULT 0,
                is_available    INTEGER DEFAULT 1,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (owner_id) REFERENCES users(id)
            )
        """)

        # BOOKINGS table - the heart of the system
        # 3 foreign keys: car, renter, owner
        self.execute("""
            CREATE TABLE IF NOT EXISTS bookings (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                car_id          INTEGER NOT NULL,
                renter_id       INTEGER NOT NULL,
                owner_id        INTEGER NOT NULL,
                start_date      TEXT NOT NULL,
                end_date        TEXT NOT NULL,
                insurance_type  TEXT DEFAULT 'none',
                insurance_fee   REAL DEFAULT 0,
                discount_code   TEXT DEFAULT NULL,
                discount_amount REAL DEFAULT 0,
                platform_fee    REAL DEFAULT 0,
                owner_amount    REAL DEFAULT 0,
                total_amount    REAL NOT NULL,
                status          TEXT DEFAULT 'pending'
                                CHECK(status IN
                                  ('pending','approved','rejected',
                                   'cancelled','completed')),
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (car_id)    REFERENCES cars(id),
                FOREIGN KEY (renter_id) REFERENCES users(id),
                FOREIGN KEY (owner_id)  REFERENCES users(id)
            )
        """)

        # REVIEWS table - bidirectional: renter->owner AND owner->renter
        self.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id      INTEGER NOT NULL,
                reviewer_id     INTEGER NOT NULL,
                reviewee_id     INTEGER NOT NULL,
                rating          INTEGER CHECK(rating BETWEEN 1 AND 5),
                comment         TEXT,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id)  REFERENCES bookings(id),
                FOREIGN KEY (reviewer_id) REFERENCES users(id),
                FOREIGN KEY (reviewee_id) REFERENCES users(id)
            )
        """)

        # INSURANCE_CLAIMS table
        self.execute("""
            CREATE TABLE IF NOT EXISTS insurance_claims (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id      INTEGER NOT NULL,
                description     TEXT NOT NULL,
                claim_amount    REAL NOT NULL,
                status          TEXT DEFAULT 'pending'
                                CHECK(status IN ('pending','approved','rejected')),
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id) REFERENCES bookings(id)
            )
        """)

    def _seed_default_admin(self):
        """Create the default admin account on first run."""
        # Import here to avoid circular imports
        from utils.security import hash_password

        # Skip if an admin already exists
        existing = self.fetch_one(
            "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
        )
        if existing is not None:
            return

        # Create the default admin
        self.execute("""
            INSERT INTO users (name, email, password_hash, phone, role, is_verified)
            VALUES (?, ?, ?, ?, 'admin', 1)
        """, ('System Admin', DEFAULT_ADMIN_EMAIL,
              hash_password(DEFAULT_ADMIN_PASSWORD), '0000000000'))
