"""OOP models - User hierarchy and entities."""
