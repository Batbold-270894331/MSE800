"""Database package - DatabaseManager Singleton."""
