"""
Configuration Module
====================
Centralized configuration for the P2P Car Rental System.

Supports multiple environments (dev, test, prod) using the
APP_ENV environment variable. Defaults to 'dev' if not set.
"""

import os

# Read the active environment from the OS environment variable, default is dev.
APP_ENV = os.environ.get('APP_ENV', 'dev').lower()

# Environment specific configuration
ENVIRONMENTS = {
    'dev': {
        'DB_FILE': 'database/car_rental.db',
        'DEBUG': True,
        'PLATFORM_FEE_PERCENT': 0.15,    # 15% commission
        'DEFAULT_ADMIN_EMAIL': 'admin@p2p.com',
        'DEFAULT_ADMIN_PASSWORD': 'admin123',
    },
    'test': {
        'DB_FILE': ':memory:',           # In-memory database
        'DEBUG': True,
        'PLATFORM_FEE_PERCENT': 0.15,
        'DEFAULT_ADMIN_EMAIL': 'admin@p2p.com',
        'DEFAULT_ADMIN_PASSWORD': 'test_admin_pwd',
    },
    'prod': {
        'DB_FILE': 'database/car_rental_prod.db',
        'DEBUG': False,
        'PLATFORM_FEE_PERCENT': 0.18,    # Higher fee in production
        'DEFAULT_ADMIN_EMAIL': 'admin@p2p.com',
        'DEFAULT_ADMIN_PASSWORD': 'change_pwd',
    },
}


# Validate the environment name
if APP_ENV not in ENVIRONMENTS:
    valid = ', '.join(ENVIRONMENTS.keys())
    raise ValueError(f"Invalid APP_ENV='{APP_ENV}'. Must be one of: {valid}")


# Export the active configuration as constants
config = ENVIRONMENTS[APP_ENV]

DB_FILE                  = config['DB_FILE']
DEBUG                    = config['DEBUG']
PLATFORM_FEE_PERCENT     = config['PLATFORM_FEE_PERCENT']
DEFAULT_ADMIN_EMAIL      = config['DEFAULT_ADMIN_EMAIL']
DEFAULT_ADMIN_PASSWORD   = config['DEFAULT_ADMIN_PASSWORD']


# Long-term rental discounts: list of (minimum days, discount fraction)
LONG_TERM_DISCOUNTS = [
    (30, 0.20),    # 30+ days = 20% off
    (7,  0.10),    # 7-29 days = 10% off
]

# Demo discount codes
DISCOUNT_CODES = {
    'SAVE10':    10,
    'WELCOME20': 20,
    'SUMMER15':  15,
}

# Password hashing salt
PASSWORD_SALT = 'private_p2p_car_rental_2026'

# Valid user roles
VALID_ROLES = ('owner', 'renter', 'admin')

def print_active_config():
    """Print the active configuration for debugging"""

    print(f"[CONFIG] Active environment: {APP_ENV}")
    print(f"[CONFIG] Database: {DB_FILE}")
    print(f"[CONFIG] Debug mode: {DEBUG}")
    print(f"[CONFIG] Platform fee: {PLATFORM_FEE_PERCENT * 100:.0f}%")
