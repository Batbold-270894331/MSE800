"""
Insurance Strategy Pattern
==========================
Implements the Strategy design pattern.

Different insurance plans (Basic, Standard, Premium) share the same
interface but calculate fees differently. The Booking uses whichever
strategy the renter chooses.
"""

from abc import ABC, abstractmethod

class InsuranceStrategy(ABC):
    """Abstract base class for all insurance strategies"""

    @property
    @abstractmethod
    def name(self):
        """Each strategy must define its name"""
        pass

    @property
    @abstractmethod
    def daily_fee(self):
        """Each strategy must define its daily fee."""
        pass

    @property
    @abstractmethod
    def coverage_limit(self):
        """Each strategy must define its coverage limit"""
        pass

    def calculate_fee(self, days):
        """Calculate the insurance fee for the given number of days.
        Same formula for all strategies, but daily_fee differs."""

        return self.daily_fee * days

    def __str__(self):
        return f"{self.name} (${self.daily_fee}/day, coverage up to ${self.coverage_limit:,.0f})"


class NoInsurance(InsuranceStrategy):
    """No insurance option"""

    @property
    def name(self):
        return 'none'

    @property
    def daily_fee(self):
        return 0.0

    @property
    def coverage_limit(self):
        return 0.0
    
    def __str__(self):
        return "No insurance"


class BasicInsurance(InsuranceStrategy):
    """Basic insurance - $5/day, $2,000 coverage"""

    @property
    def name(self):
        return 'basic'

    @property
    def daily_fee(self):
        return 5.0

    @property
    def coverage_limit(self):
        return 2000.0


class StandardInsurance(InsuranceStrategy):
    """Standard insurance - $10/day, $5,000 coverage."""

    @property
    def name(self):
        return 'standard'

    @property
    def daily_fee(self):
        return 10.0

    @property
    def coverage_limit(self):
        return 5000.0


class PremiumInsurance(InsuranceStrategy):
    """Premium insurance - $15/day, full coverage"""

    @property
    def name(self):
        return 'premium'

    @property
    def daily_fee(self):
        return 15.0

    @property
    def coverage_limit(self):
        return 999999.0


def get_insurance(name):
    """Factory helper - returns the right Strategy based on name."""

    strategies = {
        'none':     NoInsurance(),
        'basic':    BasicInsurance(),
        'standard': StandardInsurance(),
        'premium':  PremiumInsurance(),
    }

    # If name not found, default to NoInsurance
    return strategies.get(name.lower(), NoInsurance())

def list_all_insurance():
    """Return all available insurance options excluding 'none'"""
    return [BasicInsurance(), StandardInsurance(), PremiumInsurance()]
