"""
Admin Menu
==========
Admin operations:
  - Verify users
  - Approve/reject car listings
  - View platform stats
  - Suspend users
  - Handle insurance claims
"""

from services.admin_service import AdminService
from services.car_service import CarService
from services.booking_service import BookingService
from utils.helpers import (
    clear_screen, print_header, print_success, print_error,
    print_info, print_table, print_dict_as_table, prompt, prompt_int,
    format_currency, pause,
)

def show_admin_menu(user):
    """Display the admin menu."""

    admin_svc = AdminService()
    car_svc = CarService()
    booking_svc = BookingService()

    while True:
        clear_screen()
        print(user.view_dashboard())
        print()
        print("  1. View pending users (verify KYC)")
        print("  2. View pending car listings")
        print("  3. View all bookings")
        print("  4. View platform reports")
        print("  5. Suspend a user")
        print("  6. Handle insurance claims")
        print("  7. Logout")
        print()

        choice = prompt("Select option")

        if choice == '1':
            _verify_pending_users(admin_svc)
        elif choice == '2':
            _approve_pending_cars(car_svc)
        elif choice == '3':
            _view_all_bookings(booking_svc)
        elif choice == '4':
            _view_platform_stats(admin_svc)
        elif choice == '5':
            _suspend_user(admin_svc)
        elif choice == '6':
            _handle_claims(admin_svc)
        elif choice == '7':
            break
        else:
            print_error("Invalid choice")
            pause()

# 1
def _verify_pending_users(admin_svc):
    """Show and verify pending users awaiting KYC approval"""

    clear_screen()
    print_header("PENDING USER VERIFICATIONS")

    users = admin_svc.get_pending_users()
    if len(users) == 0:
        print_info("No users awaiting verification.")
        pause()
        return

    rows = []
    for u in users:
        rows.append([u['id'], u['name'], u['email'], u['role']])
    print_table(rows, ['ID', 'Name', 'Email', 'Role'])

    user_id = prompt_int("Enter user ID to verify (or 0 to skip)")
    if user_id == 0:
        return

    ok, msg = admin_svc.verify_user(user_id)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 2
def _approve_pending_cars(car_svc):
    """Show and approve pending car listings"""

    clear_screen()
    print_header("PENDING CAR LISTINGS")

    cars = car_svc.get_pending_cars()
    if len(cars) == 0:
        print_info("No pending car listings.")
        pause()
        return

    rows = []
    for car in cars:
        rows.append([
            car.id, f"{car.year} {car.make} {car.model}",
            car.location, format_currency(car.daily_rate),
        ])
    print_table(rows, ['ID', 'Vehicle', 'Location', 'Rate/day'])

    car_id = prompt_int("Enter car ID")
    print("\n  1. Approve")
    print("  2. Reject")
    action = prompt("Choose action")

    if action == '1':
        ok, msg = car_svc.approve_car(car_id)
    elif action == '2':
        ok, msg = car_svc.reject_car(car_id)
    else:
        print_error("Invalid action")
        pause()
        return

    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 3
def _view_all_bookings(booking_svc):
    """View all bookings on the platform"""

    clear_screen()
    print_header("ALL BOOKINGS")

    bookings = booking_svc.get_all_bookings()
    if len(bookings) == 0:
        print_info("No bookings yet.")
    else:
        rows = []
        for b in bookings:
            rows.append([
                b['id'], b['renter_name'], b['owner_name'],
                f"{b['year']} {b['make']} {b['model']}",
                format_currency(b['total_amount']),
                b['status'].upper(),
                b['insurance_type'].upper(),
            ])
        print_table(rows,
                    ['ID', 'Renter', 'Owner', 'Car', 'Total', 'Status', 'Insurance'])
    pause()


# 4
def _view_platform_stats(admin_svc):
    """Show platform-wide statistics"""

    clear_screen()
    print_header("PLATFORM REPORTS")

    stats = admin_svc.get_platform_stats()
    print_dict_as_table(stats)
    pause()

# 5
def _suspend_user(admin_svc):
    """Suspend a user"""
    
    clear_screen()
    print_header("SUSPEND USER")

    user_id = prompt_int("Enter user ID to suspend")
    ok, msg = admin_svc.suspend_user(user_id)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 6
def _handle_claims(admin_svc):
    """View and approve/reject pending insurance claims"""

    clear_screen()
    print_header("INSURANCE CLAIMS")

    claims = admin_svc.get_pending_claims()
    if len(claims) == 0:
        print_info("No pending insurance claims.")
        pause()
        return
    
    rows = []
    for c in claims:
        rows.append([
            c['id'], c['booking_id'],
            f"{c['make']} {c['model']}",
            f"${c['claim_amount']:.2f}",
            c['description'][:40],
        ])

    print_table(rows, ['ID', 'Booking', 'Car', 'Amount', 'Description'])
    claim_id = prompt_int("Enter claim ID")

    print("\n  1. Approve")
    print("  2. Reject")

    action = prompt("Choose action")
    if action == '1':
        ok, msg = admin_svc.approve_claim(claim_id)
    elif action == '2':
        ok, msg = admin_svc.reject_claim(claim_id)
    else:
        print_error("Invalid action")
        pause()
        return
    
    if ok:
        print_success(msg)
    else:
        print_error(msg)
        
    pause()