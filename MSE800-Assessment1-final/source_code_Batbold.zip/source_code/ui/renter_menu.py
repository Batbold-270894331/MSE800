"""
Renter Menu
===========
Handles renter operations:
  - Search and view cars
  - Make bookings with insurance and discount
  - Cancel bookings
  - Submit reviews
"""

from services.car_service import CarService
from services.booking_service import BookingService
from services.review_service import ReviewService
from services.admin_service import AdminService
from patterns.insurance_strategy import list_all_insurance
from utils.helpers import (
    clear_screen, print_header, print_section, print_success, print_error,
    print_info, print_table, print_dict_as_table, prompt, prompt_int,
    prompt_float, prompt_date, prompt_yes_no, format_currency, pause,
)
from config import DISCOUNT_CODES
from utils.validators import is_valid_date_range

def show_renter_menu(user):
    """Display the renter menu"""

    car_svc = CarService()
    booking_svc = BookingService()
    review_svc = ReviewService()
    admin_svc = AdminService()

    while True:
        clear_screen()
        print(user.view_dashboard())
        print()
        print("  1. Search cars")
        print("  2. View car details")
        print("  3. Make a booking")
        print("  4. View my bookings")
        print("  5. View profile")
        print("  6. Logout")
        print()

        choice = prompt("Select option")

        if choice == '1':
            _search_cars(car_svc)
        elif choice == '2':
            _view_car_details(car_svc)
        elif choice == '3':
            _make_booking(user, car_svc, booking_svc)
        elif choice == '4':
            _view_my_bookings(user, booking_svc, review_svc, admin_svc)
        elif choice == '5':
            _view_profile(user, review_svc)
        elif choice == '6':
            break
        else:
            print_error("Invalid choice")
            pause()

# 1
def _search_cars(car_svc):
    """Search for available cars"""

    clear_screen()
    print_header("SEARCH CARS")

    location = prompt("Filter by location (or leave empty)", allow_empty=True)
    if location == '':
        location = None

    max_price_text = prompt("Max price per day (or leave empty)", allow_empty=True)
    if max_price_text == '':
        max_price = None
    else:
        try:
            max_price = float(max_price_text)
        except ValueError:
            max_price = None

    cars = car_svc.search_cars(location=location, max_price=max_price)

    if len(cars) == 0:
        print_info("No cars match your filters.")
    else:
        rows = []
        for car in cars:
            rows.append([
                car.id, f"{car.year} {car.make} {car.model}",
                car.location, format_currency(car.daily_rate),
                f"{car.min_rent_period}-{car.max_rent_period} days",
            ])
        print_table(rows, ['ID', 'Vehicle', 'Location', 'Rate/day', 'Period'])
    pause()

# 2
def _view_car_details(car_svc):
    """View detailed information about a car"""

    clear_screen()
    print_header("VIEW CAR DETAILS")

    car_id = prompt_int("Enter car ID")
    car = car_svc.get_car_by_id(car_id)

    if car is None:
        print_error("Car not found.")
    else:
        print_dict_as_table(car.get_details(), "CAR DETAILS")
    pause()

# 3
def _make_booking(user, car_svc, booking_svc):
    """Make a new booking with insurance and discount options"""

    clear_screen()
    print_header("MAKE A BOOKING")

    # Step 1: Choose a car
    car_id = prompt_int("Enter car ID")
    car = car_svc.get_car_by_id(car_id)
    if car is None or not car.is_approved or not car.is_available:
        print_error("Car not available")
        pause()
        return

    # Step 2: Enter dates
    while True:
        start = prompt_date("Start date")
        end = prompt_date("End date")
        ok, msg = is_valid_date_range(start, end)
        if ok:
            break
        print_error(msg)

    # Step 3: Select insurance - optional
    print_section("INSURANCE OPTIONS (optional)")
    insurance_options = list_all_insurance()
    print("  1. None  ($0/day)")
    for i, ins in enumerate(insurance_options, 2):
        print(f"  {i}. {ins.name.capitalize():<8} (${ins.daily_fee}/day, "
              f"coverage ${ins.coverage_limit:,.0f})")

    ins_choice = prompt("Select insurance (1-4)")
    if ins_choice == '1':
        insurance_name = 'none'
    elif ins_choice == '2':
        insurance_name = 'basic'
    elif ins_choice == '3':
        insurance_name = 'standard'
    elif ins_choice == '4':
        insurance_name = 'premium'
    else:
        insurance_name = 'none'

    # Step 4: Apply discount code - optional
    print_section("DISCOUNT CODE (optional)")
    discount_percent = 0
    code = prompt("Enter discount code (or leave empty)", allow_empty=True)
    if code:
        code_upper = code.upper()
        if code_upper in DISCOUNT_CODES:
            discount_percent = DISCOUNT_CODES[code_upper]
            print_success(f"Discount {discount_percent}% applied!")
        else:
            print_error("Invalid discount code (ignored)")

    # Step 5: Calculate total price with breakdown
    from patterns.insurance_strategy import get_insurance

    insurance = get_insurance(insurance_name)
    pricing = booking_svc.calculate_total(car, start, end, insurance, discount_percent)

    print_section("PRICE BREAKDOWN")
    print(f"  Days:               {pricing['days']}")
    print(f"  Base price:         {format_currency(pricing['base_price'])}")

    if pricing['discount'] > 0:
        print(f"  Discount:          -{format_currency(pricing['discount'])}")

    print(f"  Owner amount:       {format_currency(pricing['owner_amount'])}")
    print(f"  Platform fee (15%): {format_currency(pricing['platform_fee'])}")

    if pricing['insurance_fee'] > 0:
        print(f"  Insurance ({pricing['insurance_name']}): "
              f"{format_currency(pricing['insurance_fee'])}")
        
    print("  " + "-" * 40)
    print(f"  TOTAL:              {format_currency(pricing['total_amount'])}")
    print()

    # Step 6: Confirm
    if not prompt_yes_no("Confirm booking?"):
        print_info("Booking cancelled.")
        pause()
        return

    # Step 7: Create the booking
    if code and discount_percent > 0:
        discount_code = code.upper()
    else:
        discount_code = None

    ok, msg, _ = booking_svc.make_booking(
        car, user.id, start, end, insurance_name, discount_percent,
        discount_code=discount_code
    )

    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 4
def _view_my_bookings(user, booking_svc, review_svc, admin_svc):
    """View renter's bookings"""

    clear_screen()
    print_header("MY BOOKINGS")

    bookings = booking_svc.get_renter_bookings(user.id)

    if len(bookings) == 0:
        print_info("You haven't made any bookings yet.")
    else:
        rows = []
        for b in bookings:
            rows.append([
                b['id'], f"{b['year']} {b['make']} {b['model']}",
                f"{b['start_date']} to {b['end_date']}",
                format_currency(b['total_amount']),
                b['status'].upper(),
                b['insurance_type'].upper(),
            ])
        print_table(rows, ['ID', 'Car', 'Period', 'Total', 'Status', 'Insurance'])

        print("\n  [1] Cancel a booking")
        print("  [2] Submit a review")
        print("  [3] View claims (if any)")
        print("  [4] Back")
        print()

        choice = prompt("Choose").strip()

        if choice == '1':
            _cancel_booking(user, booking_svc)
        elif choice == '2':
            _submit_review(user, bookings, review_svc)
        elif choice == '3':
            _view_claims(user, admin_svc)
        elif choice == '4':
            return
        else:
            print_error("Invalid choice.")
            pause()

# 4.1
def _cancel_booking(user, booking_svc):
    """Cancel a booking"""

    booking_id = prompt_int("Enter booking ID to cancel (0 to go back)")
    if booking_id == 0:
        return

    ok, msg = booking_svc.cancel_booking(booking_id, user.id)

    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 4.2
def _submit_review(user, bookings, review_svc):
    """Submit a review for a completed booking"""

    eligible = [b for b in bookings if b['status'] in ('approved', 'completed')]
    if not eligible:
        print_info("No eligible bookings to review yet.")
        pause()
        return

    rows = []
    for b in eligible:
        rows.append([b['id'], f"{b['year']} {b['make']} {b['model']}", b['status']])
    print_table(rows, ['ID', 'Car', 'Status'])

    booking_id = prompt_int("Enter booking ID (0 to go back)")
    if booking_id == 0:
        return

    booking = next((b for b in eligible if b['id'] == booking_id), None)
    if booking is None:
        print_error("Invalid booking ID.")
        pause()
        return

    rating = prompt_int("Rating (1-5)", min_value=1, max_value=5)
    comment = prompt("Comment (optional)", allow_empty=True)

    ok, msg = review_svc.submit_review(
        booking_id, user.id, booking['owner_id'], rating, comment
    )
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 4.3
def _view_claims(user, admin_svc):
    """View insurance claims for renter's bookings."""

    clear_screen()
    print_header("MY CLAIMS")

    claims = admin_svc.get_claims_by_renter(user.id)

    if not claims:
        print_info("No insurance claims found for your bookings.")
        pause()
        return

    rows = []
    for c in claims:
        rows.append([
            c['id'],
            c['booking_id'],
            f"{c['make']} {c['model']}",
            f"${c['claim_amount']:.2f}",
            c['description'][:40],
            c['status'].upper(),
        ])
    print_table(rows, ['ID', 'Booking', 'Car', 'Amount', 'Description', 'Status'])
    pause()

# 5
def _view_profile(user, review_svc):
    """View renter's profile"""

    clear_screen()

    profile = user.view_profile()
    avg = review_svc.get_user_avg_rating(user.id)
    profile['Average Rating'] = f"{avg} / 5.0" if avg > 0 else "No reviews yet"
    print_dict_as_table(profile, "MY PROFILE")
    pause()