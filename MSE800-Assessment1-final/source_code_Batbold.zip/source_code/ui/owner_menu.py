"""
Owner Menu
==========
Handles owner operations
"""

from services.car_service import CarService
from services.booking_service import BookingService
from services.review_service import ReviewService
from services.admin_service import AdminService
from utils.helpers import (
    clear_screen, print_header, print_section, print_success, print_error,
    print_info, print_table, print_dict_as_table, prompt, prompt_int,
    prompt_float, format_currency, pause,
)

def show_owner_menu(user):
    """Display the owner menu and select choices"""

    car_svc = CarService()
    booking_svc = BookingService()
    review_svc = ReviewService()
    admin_svc = AdminService()

    while True:
        clear_screen()
        print(user.view_dashboard())

        avg = review_svc.get_user_avg_rating(user.id)
        if avg > 0:
            print_info(f"Average rating: {avg}/5")

        print()
        print("  1. View my cars")
        print("  2. Add new car listing")
        print("  3. Remove car listing")
        print("  4. View pending bookings")
        print("  5. View all bookings")
        print("  6. View earnings")
        print("  7. View profile")
        print("  8. Logout")
        print()

        choice = prompt("Select option")

        if choice == '1':
            _view_my_cars(user, car_svc)
        elif choice == '2':
            _add_car(user, car_svc)
        elif choice == '3':
            _remove_car(user, car_svc)
        elif choice == '4':
            _view_pending_bookings(user, booking_svc)
        elif choice == '5':
            _view_all_bookings(user, booking_svc, review_svc, admin_svc)
        elif choice == '6':
            _view_earnings(user, booking_svc)
        elif choice == '7':
            _view_profile(user, review_svc)
        elif choice == '8':
            break
        else:
            print_error("Invalid choice")
            pause()


# 1
def _view_my_cars(user, car_svc):
    """Show the owner's car listings"""

    clear_screen()
    print_header("MY CARS")

    cars = car_svc.get_owner_cars(user.id)

    if len(cars) == 0:
        print_info("You don't have any cars listed yet.")
    else:
        rows = []
        for car in cars:
            status = "Approved" if car.is_approved else "Pending"
            rows.append([
                car.id, f"{car.year} {car.make} {car.model}",
                car.location, format_currency(car.daily_rate), status,
            ])
        print_table(rows, ['ID', 'Vehicle', 'Location', 'Rate/day', 'Status'])
    pause()


# 2
def _add_car(user, car_svc):
    """Add a new car listing"""

    clear_screen()
    print_header("ADD NEW CAR")

    make = prompt("Make (e.g. Toyota)")
    model = prompt("Model (e.g. Camry)")
    year = prompt_int("Year", min_value=1980, max_value=2030)
    mileage = prompt_int("Mileage (km)", min_value=0)
    location = prompt("Location (city)")
    daily_rate = prompt_float("Daily rate ($)", min_value=1)
    min_period = prompt_int("Min rental period (days)", min_value=1)
    max_period = prompt_int("Max rental period (days)", min_value=min_period)

    ok, msg, _ = car_svc.add_car(user.id, make, model, year, mileage,
                                  location, daily_rate, min_period, max_period)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()


# 3
def _remove_car(user, car_svc):
    """Remove a car listing"""

    clear_screen()
    print_header("REMOVE CAR")

    cars = car_svc.get_owner_cars(user.id)

    if len(cars) == 0:
        print_info("You don't have any cars to remove.")
        pause()
        return

    rows = []
    for car in cars:
        rows.append([car.id, f"{car.year} {car.make} {car.model}"])
    print_table(rows, ['ID', 'Vehicle'])

    car_id = prompt_int("Enter car ID to remove")
    ok, msg = car_svc.remove_car(user.id, car_id)

    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()


# 4
def _view_pending_bookings(user, booking_svc):
    """Show pending bookings and approve/reject from within."""

    clear_screen()
    print_header("PENDING BOOKINGS")

    bookings = booking_svc.get_owner_bookings(user.id, status='pending')

    if not bookings:
        print_info("No pending bookings.")
        pause()
        return

    rows = []
    for b in bookings:
        rows.append([
            b['id'], b['renter_name'],
            f"{b['year']} {b['make']} {b['model']}",
            f"{b['start_date']} to {b['end_date']}",
            format_currency(b['total_amount']),
            b['insurance_type'].upper(),
        ])
    print_table(rows, ['ID', 'Renter', 'Car', 'Period', 'Total', 'Insurance'])

    print("\n  [1] Approve a booking")
    print("  [2] Reject a booking")
    print("  [3] Back")
    print()

    choice = prompt("Choose").strip()

    if choice == '1':
        _approve_booking(user, bookings, booking_svc)
    elif choice == '2':
        _reject_booking(user, bookings, booking_svc)
    elif choice == '3':
        return
    else:
        print_error("Invalid choice.")
        pause()

# 4.1
def _approve_booking(user, bookings, booking_svc):
    """Approve a pending booking."""

    booking_id = prompt_int("Enter booking ID to approve (0 to go back)")
    if booking_id == 0:
        return
    ok, msg = booking_svc.approve_booking(booking_id, user.id)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 4.2
def _reject_booking(user, bookings, booking_svc):
    """Reject a pending booking."""

    booking_id = prompt_int("Enter booking ID to reject (0 to go back)")
    if booking_id == 0:
        return
    ok, msg = booking_svc.reject_booking(booking_id, user.id)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()


# 5
def _view_all_bookings(user, booking_svc, review_svc, admin_svc):
    """View all bookings with Mark as Completed and Submit Review options."""

    clear_screen()
    print_header("ALL BOOKINGS")

    bookings = booking_svc.get_owner_bookings(user.id)

    if not bookings:
        print_info("No bookings found.")
        pause()
        return

    rows = []
    for b in bookings:
        rows.append([
            b['id'], b['renter_name'],
            f"{b['year']} {b['make']} {b['model']}",
            f"{b['start_date']} to {b['end_date']}",
            format_currency(b['total_amount']),
            b['status'].upper(),
            b['insurance_type'].upper(),
        ])
    print_table(rows, ['ID', 'Renter', 'Car', 'Period', 'Total', 'Status', 'Insurance'])

    print("\n  [1] Mark as completed")
    print("  [2] Submit a review")
    print("  [3] File a claim")
    print("  [4] View claims")
    print("  [5] Back")
    print()

    choice = prompt("Choose").strip()

    if choice == '1':
        _mark_completed(user, bookings, booking_svc)
    elif choice == '2':
        _submit_review(user, bookings, review_svc)
    elif choice == '3':               
        _file_claim(user, bookings, admin_svc)
    elif choice == '4':               
        _view_claims(user, admin_svc)
    elif choice == '5':
            return
    else:
            print_error("Invalid choice.")
            pause()

# 5.1
def _mark_completed(user, bookings, booking_svc):
    """Mark an approved booking as completed."""

    eligible = [b for b in bookings if b['status'] == 'approved']
    if not eligible:
        print_info("No approved bookings to complete.")
        pause()
        return

    rows = []
    for b in eligible:
        rows.append([b['id'], b['renter_name'],
                     f"{b['start_date']} to {b['end_date']}"])
    print_table(rows, ['ID', 'Renter', 'Period'])

    booking_id = prompt_int("Enter booking ID (0 to go back)")
    if booking_id == 0:
        return

    ok, msg = booking_svc.complete_booking(booking_id, user.id)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 5.2
def _submit_review(user, bookings, review_svc):
    """Submit a review for a renter from the booking list."""

    eligible = [b for b in bookings if b['status'] == 'completed']
    if not eligible:
        print_info("No completed bookings to review yet.")
        pause()
        return

    rows = []
    for b in eligible:
        rows.append([b['id'], b['renter_name'],
                     f"{b['start_date']} to {b['end_date']}"])
    print_table(rows, ['ID', 'Renter', 'Period'])

    booking_id = prompt_int("Enter booking ID (0 to go back)")
    if booking_id == 0:
        return

    booking = next((b for b in eligible if b['id'] == booking_id), None)
    if booking is None:
        print_error("Invalid booking ID.")
        pause()
        return

    rating = prompt_int("Rating (1-5)", min_value=1, max_value=5)
    comment = prompt("Comment (optional)", allow_empty=True)

    ok, msg = review_svc.submit_review(
        booking_id,
        reviewer_id=user.id,
        reviewee_id=booking['renter_id'],
        rating=rating,
        comment=comment
    )
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 5.3
def _file_claim(user, bookings, admin_svc):
    """Owner files an insurance claim for a completed booking."""

    eligible = [b for b in bookings
                if b['status'] == 'completed' and b['insurance_type'] != 'none']
    
    if not eligible:
        print_info("No completed bookings with insurance to file a claim for.")
        pause()
        return

    rows = []
    for b in eligible:
        rows.append([
            b['id'], b['renter_name'],
            f"{b['start_date']} to {b['end_date']}",
            b['insurance_type'].capitalize(),
        ])

    print_table(rows, ['ID', 'Renter', 'Period', 'Insurance'])

    booking_id = prompt_int("Enter booking ID (0 to go back)")
    if booking_id == 0:
        return

    booking = next((b for b in eligible if b['id'] == booking_id), None)
    if booking is None:
        print_error("Invalid booking ID.")
        pause()
        return

    description = prompt("Describe the damage")
    claim_amount = prompt_float("Claim amount ($)", min_value=1)

    ok, msg, _ = admin_svc.file_claim(booking_id, description, claim_amount)
    if ok:
        print_success(msg)
    else:
        print_error(msg)
    pause()

# 5.4
def _view_claims(user, admin_svc):
    """View owner's insurance claims and their status."""

    clear_screen()
    print_header("MY CLAIMS")

    claims = admin_svc.get_claims_by_owner(user.id)

    if not claims:
        print_info("No claims found.")
        pause()
        return

    rows = []
    for c in claims:
        rows.append([
            c['id'],
            c['booking_id'],
            f"{c['make']} {c['model']}",
            f"${c['claim_amount']:.2f}",
            c['description'][:40],
            c['status'].upper(),
        ])
    print_table(rows, ['ID', 'Booking', 'Car', 'Amount', 'Description', 'Status'])
    pause()

# 6
def _view_earnings(user, booking_svc):
    """Show the owner's total earnings."""

    clear_screen()
    print_header("MY EARNINGS")

    earnings = booking_svc.get_owner_earnings(user.id)
    print()
    print_info(f"Total earnings: {format_currency(earnings)}")
    pause()

# 7
def _view_profile(user, review_svc):
    """View owner's profile"""

    clear_screen()

    profile = user.view_profile()
    avg = review_svc.get_user_avg_rating(user.id)
    profile['Average Rating'] = f"{avg} / 5.0" if avg > 0 else "No reviews yet"
    print_dict_as_table(profile, "MY PROFILE")
    pause()