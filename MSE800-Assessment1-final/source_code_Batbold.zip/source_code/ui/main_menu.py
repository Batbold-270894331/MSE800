"""
Main Menu - Entry point CLI
============================
Handles login, register, and exit
"""

import getpass
from services.auth_service import AuthService
from ui.owner_menu import show_owner_menu
from ui.renter_menu import show_renter_menu
from ui.admin_menu import show_admin_menu
from utils.helpers import (
    clear_screen, print_header, print_success, print_error,
    prompt, pause,
)

def show_main_menu():
    """Display the main menu and handle user choices"""

    auth = AuthService()

    while True:
        clear_screen()
        print_header("P2P CAR RENTAL SYSTEM")
        print()
        print("  1. Login")
        print("  2. Register")
        print("  3. Exit")
        print()

        choice = prompt("Select option")

        if choice == '1':
            _login(auth)
        elif choice == '2':
            _register(auth)
        elif choice == '3':
            print_success("See you later! Goodbye!")
            break
        else:
            print_error("Invalid choice")
            pause()

# 1
def _login(auth):
    """Handle the login flow"""

    clear_screen()
    print_header("LOGIN")

    email = prompt("Email")
    password = getpass.getpass("Password: ")

    success, message, user = auth.login(email, password)

    if not success:
        print_error(message)
        pause()
        return

    if not user.is_verified:
        print_error("Your account is not yet verified by admin.")
        pause()
        return

    print_success(message)
    pause()

    # Show menu based on role
    if user.role == 'owner':
        show_owner_menu(user)
    elif user.role == 'renter':
        show_renter_menu(user)
    elif user.role == 'admin':
        show_admin_menu(user)

# 2
def _register(auth):
    """Handle the registration flow"""

    clear_screen()
    print_header("REGISTER")

    name = prompt("Full name")
    email = prompt("Email")
    password = getpass.getpass("Password (min 6 chars): ")
    phone = prompt("Phone")

    print("\nAccount type:")
    print("  1. Owner (list cars)")
    print("  2. Renter (rent cars)")

    role_choice = prompt("Select role")
    if role_choice == '1':
        role = 'owner'
    elif role_choice == '2':
        role = 'renter'
    else:
        print_error("Invalid role")
        pause()
        return

    license_number = prompt("Driver's license number", allow_empty=True)
    if license_number == '':
        license_number = None

    success, message, user = auth.register(name, email, password, phone,
                                            role, license_number)

    if success:
        print_success(message)
    else:
        print_error(message)
    pause()
