"""
Booking Service
===============
  - Check car availability for the requested dates
  - Calculate total fee (base price, insurance, discounts, platform fee)
  - Select insurance option
  - Apply discount code as optional
"""

from database.db_manager import DatabaseManager
from patterns.insurance_strategy import get_insurance
from utils.helpers import days_between
from utils.validators import is_valid_date_range
from config import PLATFORM_FEE_PERCENT, LONG_TERM_DISCOUNTS


class BookingService:
    """Service for managing bookings"""

    def __init__(self):
        # Get the singleton database connection
        self.db = DatabaseManager()

    def check_availability(self, car_id, start_date, end_date):
        """Check if a car is free for the given date range
           Returns a tuple: (is_available, message)
        """

        # Only pending or approved bookings block the dates
        # Rejected and cancelled bookings don't matter
        rows = self.db.fetch_all("""
            SELECT id FROM bookings
            WHERE car_id = ?
              AND status IN ('pending', 'approved')
              AND NOT (end_date < ? OR start_date > ?)
        """, (car_id, start_date, end_date))

        if len(rows) > 0:
            return False, "Car is already booked during this period"
        
        return True, "Car is available"

    def calculate_total(self, car, start_date, end_date,
                        insurance, discount_percent=0):
        """Calculate the full price breakdown for a booking

        Pricing formula:
            base_price       = daily_rate * days
            long-term disc.  = 7+ days = 10% off, 30+ days = 20% off
            discount_code    = additional X% off (e.g. SAVE10 = 10%)
            owner_amount     = base_price after discounts
            platform_fee     = 15% of owner_amount
            insurance_fee    = daily_fee * days (from Strategy pattern)
            total_amount     = owner_amount + platform_fee + insurance_fee

            Returns a dictionary with all the price components
        """

        # Step 1: Calculate base price
        days = days_between(start_date, end_date)
        base_price = car.calculate_base_price(days)

        # Step 2: Apply long-term discount (only the highest tier)
        for min_days, discount_fraction in LONG_TERM_DISCOUNTS:
            if days >= min_days:
                base_price = base_price * (1 - discount_fraction)
                break  # Only apply one time

        # Step 3: Apply optional discount code, to convert percent to fraction
        discount = base_price * (discount_percent / 100)
        owner_amount = base_price - discount

        # Step 4: Calculate insurance fee handles different types and no-insurance case
        insurance_fee = insurance.calculate_fee(days)

        # Step 5: Service fee its constant commission on owner_amount
        platform_fee = owner_amount * PLATFORM_FEE_PERCENT

        # Step 6: Calculate total amount
        total_amount = owner_amount + platform_fee + insurance_fee

        # Return all components for display
        return {
            'days':           days,
            'base_price':     round(base_price, 2),
            'discount':       round(discount, 2),
            'owner_amount':   round(owner_amount, 2),
            'platform_fee':   round(platform_fee, 2),
            'insurance_fee':  round(insurance_fee, 2),
            'insurance_name': insurance.name,
            'total_amount':   round(total_amount, 2),
        }

    def make_booking(self, car, renter_id, start_date, end_date,
                     insurance_name='none', discount_percent=0,
                     discount_code=None):
        """Create a new booking (status = pending)
           Returns a tuple: (success, message, booking_id or None)
        """

        ok, msg = is_valid_date_range(start_date, end_date)
        if not ok:
            return False, msg, None

        # Step 1: Check availability
        ok, msg = self.check_availability(car.id, start_date, end_date)
        if not ok:
            return False, msg, None

        # Step 2: Check rental period limits
        days = days_between(start_date, end_date)
        if days < car.min_rent_period:
            return False, f"Minimum rental period is {car.min_rent_period} days", None
        if days > car.max_rent_period:
            return False, f"Maximum rental period is {car.max_rent_period} days", None

        # Step 3: Get insurance (case with NoInsurance)
        insurance = get_insurance(insurance_name)

        # Step 4: Calculate total
        pricing = self.calculate_total(car, start_date, end_date,
                                       insurance, discount_percent)

        # Step 5: Insert into database with status = pending
        try:
            cursor = self.db.execute("""
                INSERT INTO bookings
                  (car_id, renter_id, owner_id, start_date, end_date,
                   insurance_type, insurance_fee, discount_code, discount_amount,
                   platform_fee, owner_amount, total_amount, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
            """, (car.id, renter_id, car.owner_id, start_date, end_date,
                  insurance.name, pricing['insurance_fee'],
                  discount_code, pricing['discount'],
                  pricing['platform_fee'], pricing['owner_amount'],
                  pricing['total_amount']))

            booking_id = cursor.lastrowid
            return True, f"Booking #{booking_id} created (awaiting owner approval)", booking_id
        except Exception as e:
            return False, f"Booking failed: {e}", None

    def approve_booking(self, booking_id, owner_id):
        """Owner approves a pending booking they received
           Returns a tuple: (success, message)
        """

        # Authorization check that verifies this owner actually owns the booking
        booking = self.db.fetch_one(
            "SELECT * FROM bookings WHERE status = 'pending' AND id = ? AND owner_id = ?",
            (booking_id, owner_id)
        )

        if booking is None:
            return False, "Pending booking not found"

        # Update status to approved
        self.db.execute(
            "UPDATE bookings SET status = 'approved' WHERE id = ?",
            (booking_id,)
        )

        return True, f"Booking #{booking_id} approved"

    def reject_booking(self, booking_id, owner_id):
        """Owner rejects a pending booking
           Returns a tuple: (success, message)
        """

        booking = self.db.fetch_one(
            "SELECT * FROM bookings WHERE status = 'pending' AND id = ? AND owner_id = ?",
            (booking_id, owner_id)
        )

        if booking is None:
            return False, "Pending booking not found"

        self.db.execute(
            "UPDATE bookings SET status = 'rejected' WHERE id = ?",
            (booking_id,)
        )

        return True, f"Booking #{booking_id} rejected"

    def cancel_booking(self, booking_id, renter_id):
        """Renter cancels their own booking (if not finalized)
           Returns a tuple: (success, message)
        """

        booking = self.db.fetch_one(
            "SELECT * FROM bookings WHERE status in ('pending', 'approved') AND id = ? AND renter_id = ?",
            (booking_id, renter_id)
        )

        if booking is None:
            return False, "Pending or approved booking not found"

        self.db.execute(
            "UPDATE bookings SET status = 'cancelled' WHERE id = ?",
            (booking_id,)
        )

        return True, f"Booking #{booking_id} cancelled"

    def complete_booking(self, booking_id, owner_id):
        """Mark an approved booking as completed."""

        booking = self.db.fetch_one(
            "SELECT * FROM bookings WHERE status = 'approved' AND id = ? AND owner_id = ?",
            (booking_id, owner_id)
        )
        if booking is None:
            return False, "Approved booking not found"

        self.db.execute(
            "UPDATE bookings SET status = 'completed' WHERE id = ?",
            (booking_id,)
        )
        return True, f"Booking #{booking_id} marked as completed."

    def get_renter_bookings(self, renter_id):
        """Get all bookings for a renter with car details"""

        return self.db.fetch_all("""
            SELECT b.*, c.make, c.model, c.year
            FROM bookings b
            JOIN cars c ON b.car_id = c.id
            WHERE b.renter_id = ?
            ORDER BY b.id DESC
        """, (renter_id,))

    def get_owner_bookings(self, owner_id, status=None):
        """Get all bookings for an owner, optionally filter by status"""

        if status is not None:
            return self.db.fetch_all("""
                SELECT b.*, c.make, c.model, c.year, u.name AS renter_name
                FROM bookings b
                JOIN cars c ON b.car_id = c.id
                JOIN users u ON b.renter_id = u.id
                WHERE b.owner_id = ? AND b.status = ?
                ORDER BY b.id DESC
            """, (owner_id, status))

        # No status filter - return all
        return self.db.fetch_all("""
            SELECT b.*, c.make, c.model, c.year, u.name AS renter_name
            FROM bookings b
            JOIN cars c ON b.car_id = c.id
            JOIN users u ON b.renter_id = u.id
            WHERE b.owner_id = ?
            ORDER BY b.id DESC
        """, (owner_id,))

    def get_all_bookings(self):
        """Admin: get all bookings with all related names for review and stats"""

        return self.db.fetch_all("""
            SELECT b.*, c.make, c.model, c.year,
                   ur.name AS renter_name, uo.name AS owner_name
            FROM bookings b
            JOIN cars c ON b.car_id = c.id
            JOIN users ur ON b.renter_id = ur.id
            JOIN users uo ON b.owner_id = uo.id
            ORDER BY b.id DESC
        """)

    def get_owner_earnings(self, owner_id):
        """Calculate total earnings for an owner"""
        
        # COALESCE returns 0 if SUM returns NULL (no bookings yet)
        row = self.db.fetch_one("""
            SELECT COALESCE(SUM(owner_amount), 0) AS total
            FROM bookings
            WHERE owner_id = ?
              AND status IN ('approved', 'completed')
        """, (owner_id,))

        if row is not None:
            return row['total']
        
        return 0
