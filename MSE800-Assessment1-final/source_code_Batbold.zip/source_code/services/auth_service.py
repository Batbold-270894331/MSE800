"""
Authentication Service
======================
Handles user registration and login
"""

from database.db_manager import DatabaseManager
from factories.user_factory import UserFactory
from utils.security import hash_password, verify_password
from utils.validators import is_valid_email, is_valid_password


class AuthService:
    """Service for user authentication and registration"""

    def __init__(self):
        # Get the singleton database connection
        self.db = DatabaseManager()

    def register(self, name, email, password, phone, role,
                 license_number=None):
        """Register a new user.
           Returns a tuple: (success, message, user_or_None)
        """

        # Validate email format
        if not is_valid_email(email):
            return False, "Invalid email format", None

        # Validate password strength
        valid, msg = is_valid_password(password)
        if not valid:
            return False, msg, None

        # Only owner and renter can self-register except admin is created
        if role not in ('owner', 'renter'):
            return False, "Role must be 'owner' or 'renter'", None

        # Check if email is already used
        existing = self.db.fetch_one(
            "SELECT id FROM users WHERE email = ?", (email,)
        )
        if existing is not None:
            return False, "Email already registered", None

        # Insert the new user with is_verified = False, verified by admin
        try:
            password_hashed = hash_password(password)

            cursor = self.db.execute("""
                INSERT INTO users (name, email, password_hash, phone, role,
                                   license_number, is_verified)
                VALUES (?, ?, ?, ?, ?, ?, 0)
            """, (name, email, password_hashed, phone, role, license_number))

            user_id = cursor.lastrowid

            # Create the User object using the Factory pattern
            user = UserFactory.create(
                role=role,
                user_id=user_id,
                name=name,
                email=email,
                password_hash=password_hashed,
                phone=phone,
                license_number=license_number,
                is_verified=False,
            )
            return True, "Registration successful! Awaiting admin verification.", user
        except Exception as e:
            return False, f"Registration failed: {e}", None

    def login(self, email, password):
        """Authenticate a user.
           Returns a tuple: (success, message, user or None)
        """
        
        # Find the user by email
        row = self.db.fetch_one(
            "SELECT * FROM users WHERE email = ?", (email,)
        )
        if row is None:
            return False, "User not found", None

        # Verify the password
        if not verify_password(password, row['password_hash']):
            return False, "Incorrect password", None

        # Create the User object using the Factory pattern
        user = UserFactory.from_db_row(row)

        if not user.is_verified:
            return False, "Account not verified by admin", None
        
        return True, f"Welcome, {user.name}!", user
