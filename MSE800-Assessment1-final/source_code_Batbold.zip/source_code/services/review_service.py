"""
Review Service
==============
Manages reviews submitted after bookings are completed
"""

from database.db_manager import DatabaseManager

class ReviewService:
    """Service for managing reviews"""

    def __init__(self):
        self.db = DatabaseManager()

    def submit_review(self, booking_id, reviewer_id, reviewee_id,
                      rating, comment=''):
        """Submit a review for a completed booking.
           Returns a tuple: (success, message)
        """

        # Validate rating
        if not isinstance(rating, int):
            return False, "Rating must be a number between 1 and 5"
        if rating < 1 or rating > 5:
            return False, "Rating must be between 1 and 5"

        # Check booking exists and is in the right status
        booking = self.db.fetch_one(
            "SELECT * FROM bookings WHERE id = ?", (booking_id,)
        )
        if booking is None:
            return False, "Booking not found"

        if booking['status'] not in ('approved', 'completed'):
            return False, "Can only review approved/completed bookings"

        # Check if this user already reviewed this booking
        existing = self.db.fetch_one("""
            SELECT id FROM reviews
            WHERE booking_id = ? AND reviewer_id = ?
        """, (booking_id, reviewer_id))

        if existing is not None:
            return False, "You already reviewed this booking"

        # Insert the review
        try:
            self.db.execute("""
                INSERT INTO reviews
                  (booking_id, reviewer_id, reviewee_id, rating, comment)
                VALUES (?, ?, ?, ?, ?)
            """, (booking_id, reviewer_id, reviewee_id, rating, comment))

            return True, "Review submitted. Thanks for your feedback!"
        except Exception as e:
            return False, f"Failed to submit review: {e}"

    def get_user_avg_rating(self, user_id):
        """Calculate the average rating received by a user."""

        row = self.db.fetch_one("""
            SELECT AVG(rating) AS avg_rating, COUNT(*) AS count
            FROM reviews WHERE reviewee_id = ?
        """, (user_id,))

        if row is not None and row['count'] > 0:
            return round(row['avg_rating'], 2)
        
        return 0

    def get_reviews_for_user(self, user_id):
        """Get all reviews written about a user."""
        
        return self.db.fetch_all("""
            SELECT r.*, u.name AS reviewer_name
            FROM reviews r
            JOIN users u ON r.reviewer_id = u.id
            WHERE r.reviewee_id = ?
            ORDER BY r.id DESC
        """, (user_id,))
