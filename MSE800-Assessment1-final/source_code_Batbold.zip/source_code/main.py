"""
P2P Car Rental System - Main Entry Point
=========================================
A peer-to-peer car rental platform connecting car owners with renters.
"""

import sys

# Import config for consistent settings
from config import DEBUG, print_active_config
from database.db_manager import DatabaseManager
from ui.main_menu import show_main_menu


def main():
    """Application entry point.

    Returns:
        Exit code: 0 on success, 1 on error.
    """
    try:

        # Step 1: Show configuration values in debug mode
        if DEBUG:
            print_active_config()

        # Step 2: Initialize the Singleton database manager
        #   - Opens the SQLite connection
        #   - Creates all tables (if not exist)
        #   - Creates default admin account
        #   - All DatabaseManager() calls return this same instance
        DatabaseManager()

        # Step 3: Show the main menu
        show_main_menu()

        return 0  # exited normally

    except KeyboardInterrupt:
        # Catch Ctrl+C, not an error
        print("\n\n[INFO] Program interrupted by user. Goodbye!")
        return 0

    except Exception as e:
        # Catch exception error, print message, and exit with code 1
        print(f"\n[ERROR] {e}")

        # Show full traceback in debug mode
        if DEBUG:
            import traceback
            traceback.print_exc()
        return 1

    finally:
        # Step 4: Close the database connection
        # finally runs even after exceptions or Ctrl+C
        try:
            DatabaseManager().close()
        except Exception:
            # Don't crash on cleanup errors
            pass


# run main()
if __name__ == '__main__':
    sys.exit(main())