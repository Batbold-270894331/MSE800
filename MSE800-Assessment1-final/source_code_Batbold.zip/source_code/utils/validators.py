"""
Input validators
================
Functions to validate user inputs -> email, password strength, date formats
"""

#regular expressions for email and phone validation
import re

#datetime parsing for date validation
from datetime import datetime


def is_valid_email(email):
    """Check if the email format is valid."""

    # check email is string
    if not isinstance(email, str):
        return False
    
    # email pattern: text@mail.com
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None


def is_valid_password(password):
    """Check if the password is strong enough
       Returns a tuple: (is_valid, error_message)
    """

    if not isinstance(password, str):
        return False, "Password must be text"
    
    if len(password) < 6:
        return False, "Password must be at least 6 characters"
    
    return True, "OK"


def is_valid_date(date_string):
    """Check if the date string is in DD-MM-YYYY format"""

    try:
        datetime.strptime(date_string, "%d-%m-%Y")
        return True
    except (ValueError, TypeError):
        return False

def is_valid_date_range(start_date_string, end_date_string):
    """Check if start date is before end date"""

    if not is_valid_date(start_date_string):
        return False, "Start date format is invalid. Use DD-MM-YYYY."
    if not is_valid_date(end_date_string):
        return False, "End date format is invalid. Use DD-MM-YYYY."
    
    start = datetime.strptime(start_date_string, "%d-%m-%Y")
    end = datetime.strptime(end_date_string, "%d-%m-%Y")
    today = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    
    if start < today:
        return False, "Start date cannot be in the past."
    if end <= start:
        return False, "End date must be after start date."
    
    return True, "OK"

def is_valid_phone(phone):
    """Check if the phone number is valid"""

    if not isinstance(phone, str):
        return False
    
    # Remove spaces and dashes
    cleaned = phone.replace(' ', '').replace('-', '').replace('+', '')

    # Must be all digits and 7-15 chars long
    return cleaned.isdigit() and 7 <= len(cleaned) <= 15
