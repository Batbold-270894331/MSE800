"""
Security utilities
==================
Password hashing using SHA-256 with salt
"""

import hashlib
from config import PASSWORD_SALT


def hash_password(password):
    """Hash a password using SHA-256 with the configured salt
       Returns a hex string
    """

    # Concat password and salt before hashing
    salted = password + PASSWORD_SALT

    # hashlib requires bytes, not a string
    salted_bytes = salted.encode('utf-8')

    # hexdigest() returns a readable hex string
    return hashlib.sha256(salted_bytes).hexdigest()


def verify_password(password, hashed):
    """Verify a plain-text password against a stored hash"""
    
    return hash_password(password) == hashed
