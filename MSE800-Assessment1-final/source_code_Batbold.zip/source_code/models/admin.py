"""
Admin model - Inherits from User
=================================
Platform administrator who verifies users and approves listings.
"""

from models.user import User

class Admin(User):

    def __init__(self, user_id, name, email, password_hash, phone,
                 license_number=None, is_verified=True):
        # Admins are auto-verified and have role='admin'
        super().__init__(user_id, name, email, password_hash, phone,
                         'admin', license_number, is_verified)

    def view_dashboard(self):
        """Admin - dashboard"""
        
        return f"""
        ============================================
        ADMIN DASHBOARD - {self._name}
        ============================================
        """
