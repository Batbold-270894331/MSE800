"""
User model - Abstract base class
=================================
For Owner, Renter and Admin
"""

from abc import ABC, abstractmethod

class User(ABC):
    """Abstract base class for all users - Owner, Renter, Admin"""

    def __init__(self, user_id, name, email, password_hash, phone,
                 role, license_number=None, is_verified=False):
        
        # Accessed through @property methods below
        self._id = user_id
        self._name = name
        self._email = email
        self._password_hash = password_hash
        self._phone = phone
        self._role = role
        self._license_number = license_number
        self._is_verified = bool(is_verified)

    # access to protected attributes

    @property
    def id(self):
        return self._id

    @property
    def name(self):
        return self._name

    @property
    def email(self):
        return self._email

    @property
    def phone(self):
        return self._phone

    @property
    def role(self):
        return self._role

    @property
    def license_number(self):
        return self._license_number

    @property
    def is_verified(self):
        return self._is_verified

    @property
    def password_hash(self):
        return self._password_hash

    @abstractmethod
    def view_dashboard(self):
        """Abstract method: must implement its own dashboard"""
        pass

    def view_profile(self):
        """Return user profile information as a dictionary"""
        if self._is_verified:
            verified = "Yes"
        else:
            verified = "No (pending admin verification)"

        return {
            'ID': self._id,
            'Name': self._name,
            'Email': self._email,
            'Phone': self._phone,
            'Role': self._role.capitalize(),
            'Verified': verified,
        }

    def __str__(self):
        return f"{self._role.capitalize()}({self._name}, {self._email})"