"""
Renter model - Inherits from User
======================================
A user who rents cars from owners
"""

from models.user import User

class Renter(User):
    """Renter - searches for and books cars"""

    def __init__(self, user_id, name, email, password_hash, phone,
                 license_number=None, is_verified=False):
        super().__init__(user_id, name, email, password_hash, phone,
                         'renter', license_number, is_verified)

    def view_dashboard(self):
        """Renter - dashboard that overrides abstract method"""
        
        return f"""
        ============================================
        RENTER DASHBOARD - {self._name}
        ============================================
        """
