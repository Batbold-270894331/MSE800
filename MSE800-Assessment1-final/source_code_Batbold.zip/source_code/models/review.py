"""
Review model
============
A rating and comment left after a completed booking.
"""
class Review:
    """A review given by one user about another after a booking"""

    def __init__(self, review_id, booking_id, reviewer_id, reviewee_id,
                 rating, comment=''):
        self._id = review_id
        self._booking_id = booking_id
        self._reviewer_id = reviewer_id
        self._reviewee_id = reviewee_id
        self._rating = rating
        self._comment = comment

    @property
    def id(self):
        return self._id

    @property
    def rating(self):
        return self._rating

    @property
    def comment(self):
        return self._comment

    def validate(self):
        """Check if the rating is valid that must be 1-5"""

        if not isinstance(self._rating, int):
            return False
        if self._rating < 1 or self._rating > 5:
            return False
        
        return True