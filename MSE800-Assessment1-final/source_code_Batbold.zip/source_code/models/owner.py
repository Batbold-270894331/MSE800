"""
Owner model - Inherits from User
=================================
A car owner who can list cars and approve bookings.
"""

from models.user import User

class Owner(User):

    def __init__(self, user_id, name, email, password_hash, phone,
                 license_number=None, is_verified=False):
        # Call the parent constructor using super()
        # Pass role='owner' and is_verified = False, so must be verified by admin
        super().__init__(user_id, name, email, password_hash, phone,
                         'owner', license_number, is_verified)

    def view_dashboard(self):
        """Owner - dashboard that overrides abstract method"""
        
        return f"""
        ============================================
        OWNER DASHBOARD - {self._name}
        ============================================
        """
