"""
Database Manager - Singleton class to manage SQLite connection
==============================================================
Only one instance of the database connection exists throughout the application
"""

import sqlite3
import os

#Import from config.py to get the database file path and default admin credentials
from config import DB_FILE, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD

class DatabaseManager:
    """Singleton class for managing the SQLite database connection"""

    # Global shared variable which holds the single instance of DatabaseManager
    _instance = None

    def __new__(cls):
        """At the first time, creates the instance and initializes the database."""

        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        """Setup the database connection, create tables, and seed data for Admin"""
        
        # Check the database folder exists
        if DB_FILE != ':memory:':  # skip for in-memory DB
            db_folder = os.path.dirname(DB_FILE)
            if db_folder and not os.path.exists(db_folder):
                os.makedirs(db_folder)

        # Connect to SQLite
        # check_same_thread=False allows access from any thread
        self._connection = sqlite3.connect(DB_FILE, check_same_thread=False)

        # Make rows accessible like dictionaries using column names, row['email']
        self._connection.row_factory = sqlite3.Row

        # Enable foreign keys
        self._connection.execute("PRAGMA foreign_keys = ON")

        # Create tables and seed default admin
        self._create_tables()
        self._seed_default_admin()

    def execute(self, query, params=None):
        """Execute a parameterized SQL query using '?'"""
        cursor = self._connection.cursor()
        if params is None:
            cursor.execute(query)
        else:
            cursor.execute(query, params)

        # Saves changes for INSERT/UPDATE/DELETE queries
        self._connection.commit()
        return cursor

    def fetch_one(self, query, params=None):
        """Execute a query and return one row if exists"""

        cursor = self.execute(query, params)
        return cursor.fetchone()

    def fetch_all(self, query, params=None):
        """Execute a query and return all matching rows as a list"""
        
        cursor = self.execute(query, params)
        return cursor.fetchall()

    def close(self):
        """Close the database connection"""

        if self._connection is not None:
            self._connection.close()
            self._connection = None

            # Reset a new instance can be created later
            DatabaseManager._instance = None

    def _create_tables(self):
        """Create all tables if they don't exist"""

        # Users - stores Owner, Renter, and Admin
        self.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                name            TEXT NOT NULL,
                email           TEXT UNIQUE NOT NULL,
                password_hash   TEXT NOT NULL,
                phone           TEXT,
                role            TEXT NOT NULL
                                CHECK(role IN ('owner','renter','admin')),
                license_number  TEXT,
                is_verified     INTEGER DEFAULT 0,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Cars - each car has one owner
        self.execute("""
            CREATE TABLE IF NOT EXISTS cars (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id        INTEGER NOT NULL,
                make            TEXT NOT NULL,
                model           TEXT NOT NULL,
                year            INTEGER NOT NULL,
                mileage         INTEGER DEFAULT 0,
                location        TEXT NOT NULL,
                daily_rate      REAL NOT NULL,
                min_rent_period INTEGER DEFAULT 1,
                max_rent_period INTEGER DEFAULT 30,
                is_approved     INTEGER DEFAULT 0,
                is_available    INTEGER DEFAULT 1,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (owner_id) REFERENCES users(id)
            )
        """)

        # Bookings - main transaction table
        # 3 foreign keys: car, renter, owner
        self.execute("""
            CREATE TABLE IF NOT EXISTS bookings (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                car_id          INTEGER NOT NULL,
                renter_id       INTEGER NOT NULL,
                owner_id        INTEGER NOT NULL,
                start_date      TEXT NOT NULL,
                end_date        TEXT NOT NULL,
                insurance_type  TEXT DEFAULT 'none',
                insurance_fee   REAL DEFAULT 0,
                discount_code   TEXT DEFAULT NULL,
                discount_amount REAL DEFAULT 0,
                platform_fee    REAL DEFAULT 0,
                owner_amount    REAL DEFAULT 0,
                total_amount    REAL NOT NULL,
                status          TEXT DEFAULT 'pending'
                                CHECK(status IN
                                  ('pending','approved','rejected',
                                   'cancelled','completed')),
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (car_id)    REFERENCES cars(id),
                FOREIGN KEY (renter_id) REFERENCES users(id),
                FOREIGN KEY (owner_id)  REFERENCES users(id)
            )
        """)

        # Reviews - renter -> owner, owner -> renter
        self.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id      INTEGER NOT NULL,
                reviewer_id     INTEGER NOT NULL,
                reviewee_id     INTEGER NOT NULL,
                rating          INTEGER CHECK(rating BETWEEN 1 AND 5),
                comment         TEXT,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id)  REFERENCES bookings(id),
                FOREIGN KEY (reviewer_id) REFERENCES users(id),
                FOREIGN KEY (reviewee_id) REFERENCES users(id)
            )
        """)

        # Insurance claims - linked to bookings
        self.execute("""
            CREATE TABLE IF NOT EXISTS insurance_claims (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id      INTEGER NOT NULL,
                description     TEXT NOT NULL,
                claim_amount    REAL NOT NULL,
                status          TEXT DEFAULT 'pending'
                                CHECK(status IN ('pending','approved','rejected')),
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id) REFERENCES bookings(id)
            )
        """)

    def _seed_default_admin(self):
        """Create the default admin account on first run if it doesn't exist"""

        # Import hash_password from utils
        from utils.security import hash_password

        # Skip if an admin already exists
        existing = self.fetch_one(
            "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
        )
        
        if existing is not None:
            return

        # Create the default admin
        self.execute("""
            INSERT INTO users (name, email, password_hash, phone, role, is_verified)
            VALUES (?, ?, ?, ?, 'admin', 1)
        """, ('System Admin', DEFAULT_ADMIN_EMAIL,
              hash_password(DEFAULT_ADMIN_PASSWORD), '0000000000'))