"""
User Factory
======================================
Creates the User subclass based on role
"""

from models.owner import Owner
from models.renter import Renter
from models.admin import Admin


class UserFactory:
    """Factory class for creating User instances based on role"""

    # Static method to create a User instance without createing an instance of UserFactory
    @staticmethod
    def create(role, user_id, name, email, password_hash, phone,
               license_number=None, is_verified=False):
        """Create a User instance (role: owner, renter, or admin) using a role."""

        role = role.lower()

        if role == 'owner':
            return Owner(user_id, name, email, password_hash, phone,
                         license_number, is_verified)
        elif role == 'renter':
            return Renter(user_id, name, email, password_hash, phone,
                          license_number, is_verified)
        elif role == 'admin':
            return Admin(user_id, name, email, password_hash, phone,
                         license_number, is_verified)
        else:
            # Raise an error for unknown roles
            raise ValueError(f"Unknown role: {role}")

    @staticmethod
    def from_db_row(row):
        """Create a User instance from a data row as a dictionary"""

        # license_number default to None if not present
        license_number = None
        if 'license_number' in row.keys():
            license_number = row['license_number']

        return UserFactory.create(
            role=row['role'],
            user_id=row['id'],
            name=row['name'],
            email=row['email'],
            password_hash=row['password_hash'],
            phone=row['phone'],
            license_number=license_number,
            is_verified=row['is_verified'],
        )
